(function($){

	$(document).ready(function() {
	
		
		$('li.carrot-archive-year a.icon').click(function() {
			$(this).toggleClass('more');
				
			$(this).parent().children('ul').slideToggle('fast');
			return false;
		});	
		$('.widget_carrotarchivewidget li:first-child').find('a').click();
	});

})(jQuery);