<?php 


class Carrot_PSR_Best_Of_Moment_Widget extends WP_Widget {

	function Carrot_PSR_Best_Of_Moment_Widget() {
		/* Widget settings. */
		$widget_ops = array( 
			'classname' => 'Carrot_PSR_Best_Of_Moment_Widget', 
			'description' => __('Llista les entrades millor valorades del mes',CARROT_PSR_TEXTDOMAIN)
		);

		/* Create the widget. */
		$this->WP_Widget( 'CarrotPSRBestOfMomentWidget-widget', 'Carrot PSR Best Of Moment Widget', $widget_ops);
	}
	
	
	function widget( $args, $instance ) {
		global $wpdb;
		extract( $args );

		/* User-selected settings. */
		$title = apply_filters('widget_title', $instance['title'] );
		
		$show_foto = isset( $instance['SHOW_AVATAR'] ) ? $instance['SHOW_AVATAR'] : false;
		$limit_number = isset( $instance['LIMIT_NUMBER'] ) ? $instance['LIMIT_NUMBER'] : "";
		$show_count = isset( $instance['VOTE_COUNT'] ) ? $instance['VOTE_COUNT'] : false;
		
		
		if(is_nan((int)$limit_number)) $limit_number="";
		
		/* Before widget (defined by themes). */
		echo $before_widget;

		/* Title of widget (before and after defined by themes). */
		if ( $title )
			echo $before_title . $title . $after_title;

		
		$args=array(
			"show_foto"=>$show_foto,
			"limit_number"=>$limit_number,
			"show_count"=>$show_count
		);
		
		echo carrot_psr_bests_of_moment($args);
		

		/* After widget (defined by themes). */
		echo $after_widget;
	}
	
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
		/* Strip tags (if needed) and update the widget settings. */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['SHOW_AVATAR'] = $new_instance['SHOW_AVATAR'];
		$instance['FOTO_TYPE'] = $new_instance['FOTO_TYPE'];
		$instance['LIMIT_NUMBER'] = $new_instance['LIMIT_NUMBER'];
		$instance['VOTE_COUNT'] = $new_instance['VOTE_COUNT'];

		
		
		return $instance;
	}
	
	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 
			'title' => __('Moment Votes',CARROT_PSR_TEXTDOMAIN), 
			'SHOW_AVATAR' => true,
			'FOTO_TYPE' => "featured",
			'LIMIT_NUMBER' => "",
			'VOTE_COUNT' => true
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		//print_r($instance);
?>
			<p>
				<label for="<?=$this->get_field_id( 'title' ) ?>"><?=__('Títol:',CARROT_PSR_TEXTDOMAIN)?></label>
				<input name="<?=$this->get_field_name( 'title' )?>" id="<?=$this->get_field_id( 'title' ) ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_AVATAR' )?>"><?=__('Mostrar imatge:',CARROT_PSR_TEXTDOMAIN)?></label>
				<input type="checkbox" <?php checked( $instance['SHOW_AVATAR'], 'on' ); ?>  name="<?=$this->get_field_name( 'SHOW_AVATAR' )?>" id="<?=$this->get_field_id( 'SHOW_AVATAR' ) ?>"  />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'VOTE_COUNT' )?>"><?=__('Mostrar número de vots:',CARROT_PSR_TEXTDOMAIN)?></label>
				<input type="checkbox" <?php checked( $instance['VOTE_COUNT'], 'on' ); ?>  name="<?=$this->get_field_name( 'VOTE_COUNT' )?>" id="<?=$this->get_field_id( 'VOTE_COUNT' ) ?>"  />
			</p>
			
			
			
			<p>
				<label for="<?=$this->get_field_id( 'LIMIT_NUMBER' )?>"><?=__("Número d'articles mostrats:",CARROT_PSR_TEXTDOMAIN)?></label>
				<input type="text" name="<?=$this->get_field_name( 'LIMIT_NUMBER' )?>" id="<?=$this->get_field_id( 'LIMIT_NUMBER' ) ?>"  value="<?=$instance['LIMIT_NUMBER']?>"/>
				<br/>
				<em><small><?=__("Deixant en blanc no hi haurà límit",CARROT_PSR_TEXTDOMAIN)?></small></em>
			</p>		
	
<?php
	}
}


add_action('widgets_init', create_function('', 'return register_widget("Carrot_PSR_Best_Of_Moment_Widget");'));







