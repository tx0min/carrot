<?php
/*
Plugin Name: Carrot Popular Posts
Description: Llista les entrades més populars (més llegides)
Version: 1.0
Author: Mensula
*/


define("CARROT_POST_VIEWED_KEY",'carrot_post_views_count');
define("CARROT_POST_VIEWED_COOKIE",'carrot_post_viewed');

class Carrot_Popular_Posts_Widget extends WP_Widget {

	function Carrot_Popular_Posts_Widget() {
		/* Widget settings. */
		$widget_ops = array( 
			'classname' => 'Carrot_Popular_Posts_Widget', 
			'description' => __('Show the most popular posts',"carrot_popular_posts_widget") 
		);

		
		/* Create the widget. */
		$this->WP_Widget( 'CarrotPopularPostsWidget-widget', 'Carrot Popular Posts Widget', $widget_ops);
	}

	
	
	function widget( $args, $instance ) {
		extract( $args );

		/* User-selected settings. */
		$title = apply_filters('widget_title', $instance['title'] );
		
		$show_image = isset( $instance['SHOW_IMAGE'] ) ? $instance['SHOW_IMAGE'] : false;
		$show_count = isset( $instance['SHOW_COUNT'] ) ? $instance['SHOW_COUNT'] : false;
		$limit_number = isset( $instance['LIMIT_NUMBER'] ) ? $instance['LIMIT_NUMBER'] : "";
		
		if(is_nan((int)$limit_number)) $limit_number="";
		
		$post_types = isset( $instance['POST_TYPES'] ) ? $instance['POST_TYPES'] : "post";
		
		/* Before widget (defined by themes). */
		echo $before_widget;

		/* Title of widget (before and after defined by themes). */
		if ( $title )
			echo $before_title . $title . $after_title;

		
		$args=array( 
			'meta_key' => CARROT_POST_VIEWED_KEY, 
			'orderby' => 'meta_value_num', 
			'order' => 'DESC'  ,
			'ignore_sticky_posts' => true  
			
		) ;
		
		if($limit_number && $limit_number>0){
			$args['posts_per_page'] = $limit_number; 
		}
			
	//	_dump($args);
		$popularpost = new WP_Query( $args );
		$colsize=12;
		if($show_image) $colsize=9;

		

		if ( $popularpost->have_posts() ) :
			while ( $popularpost->have_posts() ) : $popularpost->the_post();
?>

<article class="article-separation-smallgap header-separation-none thumb-left foto-featured">

	<div class="article-inner">
	
		<div class="row">
				<?php if($show_image){?>
					<div class="col-xs-<?=(12-$colsize)?>">
						<div class="article-featured ">
							<?php 
								theme_post_thumbnail('icon',false, false, true); 
								
							?>
						</div>
					</div>
				<?php }?>		
						
				<div class="col-xs-<?=$colsize?>">
					<header class="entry-header clearfix">
						<h3 class="entry-title ">
							<a href="<?php the_permalink();?>"><?php the_title();?></a>
						</h3>
														
						
						
						<div class="article-date"><?php theme_posted_on(); ?></div>
						
							
						<?php if($show_count){ ?>
							<div class="article-views">
								| <?php  theme_view_count(); ?>
							</div>
						<?php } ?>
					</header><!-- .entry-header -->
				</div>
						
		</div>
	</div>
</article>

<?php
			endwhile;
		endif;
		
		wp_reset_postdata(); 

		/* After widget (defined by themes). */
		echo $after_widget;
	}
	
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
		/* Strip tags (if needed) and update the widget settings. */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['LIMIT_NUMBER'] = $new_instance['LIMIT_NUMBER'];
		$instance['SHOW_IMAGE'] = $new_instance['SHOW_IMAGE'];
		$instance['SHOW_COUNT'] = $new_instance['SHOW_COUNT'];
		//_dump($new_instance); die();
		$instance['POST_TYPES'] = $new_instance['POST_TYPES'];
		
		
		return $instance;
	}
	
	function form( $instance ) {

		$defaults = array( 
			'title' => __('Most Popular',"carrot_popular_posts_widget"), 
			"LIMIT_NUMBER" => 5,
			"SHOW_IMAGE" => false,
			"SHOW_COUNT" => true,
			'POST_TYPES' => 'post'
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		//print_r($instance);
?>
			
			<p>
				<label for="<?=$this->get_field_id( 'title' ) ?>"><?=__("Title:","carrot_popular_posts_widget")?></label>
				<input type="hidden" name="CarrotPopularPostsWidget_update" value="1"/>
				<input name="<?=$this->get_field_name( 'title' ) ?>" id="<?=$this->get_field_id( 'title' ) ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</p>
			
			<p>
			<?php
				$types=get_post_types(); 
			?>
				<label for="<?php echo $this->get_field_id( 'POST_TYPES' ); ?>"><?=__("Post type/s:","carrot_popular_posts_widget")?></label> 
				<select multiple="true" id="<?php echo $this->get_field_id( 'POST_TYPES' ); ?>" name="<?php echo $this->get_field_name( 'POST_TYPES' ); ?>[]" class="widefat" >
			<?php
			
				$currenttypes=$instance['POST_TYPES'];
				foreach ($types as $type ) {
					//print_r($taxonomy);
					echo "<option value=\"".$type."\" ";
					if ( in_array($type,$currenttypes) ) echo " selected='selected' " ;
				  
				  echo ">".$type."</option>";
				}
			?>
					
					
				</select>
			</p>
			
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_IMAGE' ) ?>"><?=__("Show image:","carrot_popular_posts_widget")?></label>
				<input name="<?=$this->get_field_name( 'SHOW_IMAGE' ) ?>" id="<?=$this->get_field_id( 'SHOW_IMAGE' ) ?>" type="checkbox" <?php checked( $instance['SHOW_IMAGE'], 'on' ); ?>  />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_COUNT' ) ?>"><?=__("Show count:","carrot_popular_posts_widget")?></label>
				<input name="<?=$this->get_field_name( 'SHOW_COUNT' ) ?>" id="<?=$this->get_field_id( 'SHOW_COUNT' ) ?>" type="checkbox" <?php checked( $instance['SHOW_COUNT'], 'on' ); ?> />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'LIMIT_NUMBER' )?>"><?=__("Limit number:","carrot_popular_posts_widget")?></label>
				<input type="text" name="<?=$this->get_field_name( 'LIMIT_NUMBER' )?>" id="<?=$this->get_field_id( 'LIMIT_NUMBER' ) ?>"  value="<?=$instance['LIMIT_NUMBER']?>"/>
				<br/>
				<em><small><?=__("Leave blank for unlimited","carrot_popular_posts_widget")?></small></em>
			</p>
	
			
			
	
<?php
	}
}

function Carrot_Popular_Posts_Widget_style() {
	$plugin_url = plugins_url ( plugin_basename ( dirname ( __FILE__ ) ) );
	
	wp_register_style('Carrot_Popular_Posts_Widget_style', $plugin_url.'/style.css');
	wp_enqueue_style( 'Carrot_Popular_Posts_Widget_style');
}


function carrot_set_post_views($postID) {
    carrot_inc_post_meta_num($postID,CARROT_POST_VIEWED_KEY);
}


function carrot_track_post_views ($post_id) {
    if ( !is_single()) return;

    if ( empty ( $post_id) ) {
        global $post;
        $post_id = $post->ID;    
    }
	if(!carrot_post_views_has_cookie($post_id)) carrot_set_post_views($post_id);

}


function carrot_post_views_set_cookie() {
	carrot_set_post_cookie(CARROT_POST_VIEWED_COOKIE);	
}


function carrot_get_post_views($postID){
    return carrot_get_post_meta_num($postID,CARROT_POST_VIEWED_KEY);
}

function carrot_post_views_has_cookie($postID) {
	return carrot_has_post_cookie(CARROT_POST_VIEWED_COOKIE,$postID);
}



//To keep the count accurate, lets get rid of prefetching
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

add_action( 'wp_head', 'carrot_track_post_views');
add_action( 'init', 'carrot_post_views_set_cookie');

add_action('wp_print_styles', 'Carrot_Popular_Posts_Widget_style');

add_action('widgets_init', create_function('', 'return register_widget("Carrot_Popular_Posts_Widget");'));


