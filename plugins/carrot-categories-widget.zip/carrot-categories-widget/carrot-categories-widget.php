<?php
/*
Plugin Name: Carrot Categories with Color
Description: Llista les categories del blog amb el color corresponent
Version: 1.0
Author: Mensula
*/


class Carrot_Categories_Widget extends WP_Widget {

	function Carrot_Categories_Widget() {
		/* Widget settings. */
		$widget_ops = array( 
			'classname' => 'Carrot_Categories_Widget', 
			'description' => __('Show the blog categories (with color)' ,"carrot_categories_widget")
		);

		
		/* Create the widget. */
		$this->WP_Widget( 'CarrotCategoriesWidget-widget', 'Carrot Categories Widget', $widget_ops);
	}
	
	function widget( $args, $instance ) {
		extract( $args );

		/* User-selected settings. */
		$title = apply_filters('widget_title', $instance['title'] );
		
		//$NUMERO_POSTS = $instance['NUMERO_POSTS'];
		$show_color = isset( $instance['SHOW_COLOR'] ) ? $instance['SHOW_COLOR'] : false;
		$show_image = isset( $instance['SHOW_IMAGE'] ) ? $instance['SHOW_IMAGE'] : false;
		$show_count = isset( $instance['SHOW_COUNT'] ) ? $instance['SHOW_COUNT'] : false;
		$hide_empty = isset( $instance['HIDE_EMPTY'] ) ? $instance['HIDE_EMPTY'] : false;
		
		$order_by = isset( $instance['ORDER_BY'] ) ? $instance['ORDER_BY'] : "name";
		$taxonomy = isset( $instance['TAXONOMY'] ) ? $instance['TAXONOMY'] : "category";
		$order_dir=(($order_by=="count")?"DESC":"ASC");
		
		/* Before widget (defined by themes). */
		echo $before_widget;

		/* Title of widget (before and after defined by themes). */
		if ( $title )
			echo $before_title . $title . $after_title;

		
		
		$catargs = array(
			'type'                     => 'post',
			'orderby'                  => $order_by,
			'order'                    => $order_dir,
			'hide_empty'               => $hide_empty,
			'taxonomy'                 => $taxonomy,
			'pad_counts'               => true );
		
	   $categories = get_categories( $catargs );
	    
		/*error_reporting(E_ALL);
		ini_set('display_errors', 1);*/

	   $ret= "<ul ".(($show_image)?"class='term-images-list'":"").">\n";
		
	 
		//var_dump(get_terms($taxonomy));
	 
	   foreach($categories as $cat){
			
			
			
			$color="";
			$icon="";
			if(function_exists('get_field')){
				$color=get_field('color', $cat->taxonomy.'_'.$cat->term_id);
				$icon=get_field('icono', $cat->taxonomy.'_'.$cat->term_id);
			}
			
			$url=get_term_link($cat->slug,$cat->taxonomy);
			
			$ret.= "<li class='cat_".$cat->term_id."'>\n";
			$ret.="<div class='row'>\n";
			
			if($show_image){
				$ret.="<div class='col-xs-2'>";
					
					$ret.="<img class='category-icon' src=\"".$icon["url"]."\"/>\n";
					$ret.="</a>\n";
			
				$ret.="</div>\n";
				$ret.="<div class='col-xs-10'>";
			}else{
				$ret.="<div class='col-xs-12'>";
			}
			
			$ret.="<a href='".$url."'>\n";
				if($show_color) $ret.="<span class='category-color' style='background-color:".$color."'></span>\n";
				$ret.="<span class='category-name'>".$cat->name."</span>\n";
			$ret.="</a>\n";
			
			if($show_count) $ret.="<span class='count bg-primary'>".$cat->count."</span>\n";
			

			$ret.="</div>\n";
			
			
			$ret.="</li>\n";
			
			
			
			
			
	    }
	   
	   $ret.= "</ul>\n";
		
		echo $ret;
		

		/* After widget (defined by themes). */
		echo $after_widget;
	}
	
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
		/* Strip tags (if needed) and update the widget settings. */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['SHOW_COLOR'] = $new_instance['SHOW_COLOR'];
		$instance['SHOW_IMAGE'] = $new_instance['SHOW_IMAGE'];
		$instance['SHOW_COUNT'] = $new_instance['SHOW_COUNT'];
		$instance['HIDE_EMPTY'] = $new_instance['HIDE_EMPTY'];
		$instance['ORDER_BY'] = $new_instance['ORDER_BY'];
		$instance['TAXONOMY'] = $new_instance['TAXONOMY'];
		
		
		return $instance;
	}
	
	function form( $instance ) {

		$defaults = array( 
			'title' => 'Categories', 
			"SHOW_COLOR" => true,
			"SHOW_IMAGE" => false,
			"SHOW_COUNT" => true,
			"HIDE_EMPTY" => true,
			'ORDER_BY' => 'name', 
			'TAXONOMY' => 'category'
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		//print_r($instance);
?>
			
			<p>
				<label for="<?=$this->get_field_id( 'title' ) ?>"><?=__("Title:","carrot_categories_widget")?></label>
				<input type="hidden" name="CarrotCategoriesWidget_update" value="1"/>
				<input name="<?=$this->get_field_name( 'title' ) ?>" id="<?=$this->get_field_id( 'title' ) ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</p>
			
			<p>
			<?php
				$taxonomies=get_taxonomies('','objects'); 
			?>
				<label for="<?php echo $this->get_field_id( 'TAXONOMY' ); ?>"><?=__("Taxonomy:","carrot_categories_widget")?></label> 
				<select id="<?php echo $this->get_field_id( 'TAXONOMY' ); ?>" name="<?php echo $this->get_field_name( 'TAXONOMY' ); ?>" class="widefat" >
			<?php
				foreach ($taxonomies as $taxonomy ) {
					//print_r($taxonomy);
				 echo '<option value="'.$taxonomy->name.'" ';
				  if ( $taxonomy->name == $instance['TAXONOMY'] ) echo ' selected="selected" ' ;
				  echo '>'.$taxonomy->label.'</option>';
				}
			?>
					
					
				</select>
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_COLOR' ) ?>"><?=__("Show color:","carrot_categories_widget")?></label>
				<input name="<?=$this->get_field_name( 'SHOW_COLOR' ) ?>" id="<?=$this->get_field_id( 'SHOW_COLOR' ) ?>" type="checkbox" <?php checked( $instance['SHOW_COLOR'], 'on' ); ?>  />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_IMAGE' ) ?>"><?=__("Show imatge:","carrot_categories_widget")?></label>
				<input name="<?=$this->get_field_name( 'SHOW_IMAGE' ) ?>" id="<?=$this->get_field_id( 'SHOW_IMAGE' ) ?>" type="checkbox" <?php checked( $instance['SHOW_IMAGE'], 'on' ); ?>  />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_COUNT' ) ?>"><?=__("Show article number:","carrot_categories_widget")?></label>
				<input name="<?=$this->get_field_name( 'SHOW_COUNT' ) ?>" id="<?=$this->get_field_id( 'SHOW_COUNT' ) ?>" type="checkbox" <?php checked( $instance['SHOW_COUNT'], 'on' ); ?> />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'HIDE_EMPTY' ) ?>"><?=__("Add empty categories:","carrot_categories_widget")?></label>
				<input name="<?=$this->get_field_name( 'HIDE_EMPTY' ) ?>" id="<?=$this->get_field_id( 'HIDE_EMPTY' ) ?>" type="checkbox" <?php checked( $instance['HIDE_EMPTY'], 'on' ); ?> />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'ORDER_BY' ); ?>"><?=__("Order by:","carrot_categories_widget")?></label> 
				<select id="<?php echo $this->get_field_id( 'ORDER_BY' ); ?>" name="<?php echo $this->get_field_name( 'ORDER_BY' ); ?>" class="widefat" >
					<option <?php if ( 'nom' == $instance['ORDER_BY'] ) echo 'selected="selected"'; ?> value="nom"><?=__("Name","carrot_categories_widget")?></option>
					<option <?php if ( 'count' == $instance['ORDER_BY'] ) echo 'selected="selected"'; ?> value="count"><?=__("Post count","carrot_categories_widget")?></option>
				</select>
			</p>
			
			
	
<?php
	}
}

function Carrot_Categories_Widget_style() {
	$plugin_url = plugins_url ( plugin_basename ( dirname ( __FILE__ ) ) );
	
	wp_register_style('Carrot_Categories_Widget_style', $plugin_url.'/style.css');
	wp_enqueue_style( 'Carrot_Categories_Widget_style');
}

add_action('wp_print_styles', 'Carrot_Categories_Widget_style');

add_action('widgets_init', create_function('', 'return register_widget("Carrot_Categories_Widget");'));


