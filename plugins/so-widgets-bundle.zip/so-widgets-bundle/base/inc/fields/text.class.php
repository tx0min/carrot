<?php

/**
 * The common functionality in the base class is all this class needs. It exists to satisfy the class naming convention
 * used to instantiate classes in `SiteOrigin_Widget_Field_Factory`
 *
 * Class SiteOrigin_Widget_Field_Text
 */
class SiteOrigin_Widget_Field_Text extends SiteOrigin_Widget_Field_Text_Input_Base {

}