<?php
/*
Plugin Name: TXO List Authors with image
Description: Llista els autors del blog amb imatge 
Version: 1.0
Author: Mensula
*/

class TXO_Authors_Widget extends WP_Widget {

	function TXO_Authors_Widget() {
		/* Widget settings. */
		$widget_ops = array( 
			'classname' => 'TXO_Authors_Widget', 
			'description' => 'Llista els autors del blog amb imatge' 
		);

		/* Widget control settings. */
		//$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'example-widget' );

		/* Create the widget. */
		$this->WP_Widget( 'TXOAuthorsWidget-widget', 'TXO Authors Widget', $widget_ops);
	}
	
	function widget( $args, $instance ) {
		extract( $args );

		/* User-selected settings. */
		$title = apply_filters('widget_title', $instance['title'] );
		//$NUMERO_POSTS = $instance['NUMERO_POSTS'];
		$show_foto = isset( $instance['SHOW_AVATAR'] ) ? $instance['SHOW_AVATAR'] : false;
		$show_carrec = isset( $instance['SHOW_CARREC'] ) ? $instance['SHOW_CARREC'] : false;
		$show_twitter = isset( $instance['SHOW_TWITTER'] ) ? $instance['SHOW_TWITTER'] : false;
		$show_email = isset( $instance['SHOW_EMAIL'] ) ? $instance['SHOW_EMAIL'] : false;
		$show_count = isset( $instance['SHOW_COUNT'] ) ? $instance['SHOW_COUNT'] : false;
		$limit_number = isset( $instance['LIMIT_NUMBER'] ) ? $instance['LIMIT_NUMBER'] : "";
		
		if(is_nan((int)$limit_number)) $limit_number="";
		
		/* Before widget (defined by themes). */
		echo $before_widget;

		/* Title of widget (before and after defined by themes). */
		if ( $title )
			echo $before_title . $title . $after_title;

		
		global $wpdb;
		
		
		$q="SELECT post_author,count(*) as c FROM $wpdb->posts WHERE post_status='publish' and post_type='post' group by post_author order by c desc";
		if($limit_number && $limit_number>0) $q.=" limit ".$limit_number;
		
		$authors = $wpdb->get_results($q);

		echo "<ul ".($show_foto?"":"class='no-foto'").">\n";
		
		$options=array(
			"name"=>true,
			"avatar"=>$show_foto,
			"bio"=>$show_carrec,
			"prefix"=>false,
			"twitter"=>$show_twitter,
			"email"=>$show_email,
		);
			
		foreach($authors as $u){
			$user=(get_userdata($u->post_author));
			echo "<li class='clearfix'>\n";
			
			theme_author_args($options,$u->post_author);
			if($show_count) echo "<span class='count bg-alt'>".count_user_posts( $u->post_author ) ."</span>\n";
			echo "\n</li>\n";
			
		}
		echo "</ul>\n";
		
		

		/* After widget (defined by themes). */
		echo $after_widget;
	}
	
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
		/* Strip tags (if needed) and update the widget settings. */
		$instance['title'] = strip_tags( $new_instance['title'] );
		//$instance['NUMERO_POSTS'] = strip_tags( $new_instance['NUMERO_POSTS'] );
		$instance['SHOW_AVATAR'] = $new_instance['SHOW_AVATAR'];
		$instance['SHOW_CARREC'] = $new_instance['SHOW_CARREC'];
		$instance['SHOW_TWITTER'] = $new_instance['SHOW_TWITTER'];
		$instance['SHOW_EMAIL'] = $new_instance['SHOW_EMAIL'];
		$instance['SHOW_COUNT'] = $new_instance['SHOW_COUNT'];
		$instance['LIMIT_NUMBER'] = $new_instance['LIMIT_NUMBER'];
		
		
		return $instance;
	}
	
	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 
			'title' => __('Autors',"TXOAuthorsWidget"), 
			'SHOW_AVATAR' => true, 
			'SHOW_CARREC' => true, 
			'SHOW_TWITTER' => false, 
			'SHOW_EMAIL' => false, 
			'SHOW_COUNT' => true,
			'LIMIT_NUMBER' => ""
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		//print_r($instance);
?>
			<p>
				<label for="<?=$this->get_field_id( 'title' ) ?>"><?=__('Títol:',"TXOAuthorsWidget")?></label>
				<input name="<?=$this->get_field_name( 'title' )?>" id="<?=$this->get_field_id( 'title' ) ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_AVATAR' )?>"><?=__('Mostrar foto:',"TXOAuthorsWidget")?></label>
				<input type="checkbox" <?php checked( $instance['SHOW_AVATAR'], 'on' ); ?>  name="<?=$this->get_field_name( 'SHOW_AVATAR' )?>" id="<?=$this->get_field_id( 'SHOW_AVATAR' ) ?>"  />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_CARREC' )?>"><?=__('Mostrar càrrec:',"TXOAuthorsWidget")?></label>
				<input type="checkbox" <?php checked( $instance['SHOW_CARREC'], 'on' ); ?>  name="<?=$this->get_field_name( 'SHOW_CARREC' )?>" id="<?=$this->get_field_id( 'SHOW_CARREC' ) ?>"  />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_TWITTER' )?>"><?=__('Mostrar twitter:',"TXOAuthorsWidget")?></label>
				<input type="checkbox" <?php checked( $instance['SHOW_TWITTER'], 'on' ); ?>  name="<?=$this->get_field_name( 'SHOW_TWITTER' )?>" id="<?=$this->get_field_id( 'SHOW_TWITTER' ) ?>"  />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_EMAIL' )?>"><?=__('Mostrar email:',"TXOAuthorsWidget")?></label>
				<input type="checkbox" <?php checked( $instance['SHOW_EMAIL'], 'on' ); ?>  name="<?=$this->get_field_name( 'SHOW_EMAIL' )?>" id="<?=$this->get_field_id( 'SHOW_EMAIL' ) ?>"  />
			</p>
			
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_COUNT' )?>"><?=__("Mostrar número d'articles:","TXOAuthorsWidget")?></label>
				<input type="checkbox" <?php checked( $instance['SHOW_COUNT'], 'on' ); ?>  name="<?=$this->get_field_name( 'SHOW_COUNT' )?>" id="<?=$this->get_field_id( 'SHOW_COUNT' ) ?>"  />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'LIMIT_NUMBER' )?>"><?=__("Limitar nombre d'autors:","TXOAuthorsWidget")?></label>
				<input type="text" name="<?=$this->get_field_name( 'LIMIT_NUMBER' )?>" id="<?=$this->get_field_id( 'LIMIT_NUMBER' ) ?>"  value="<?=$instance['LIMIT_NUMBER']?>"/>
				<br/>
				<em><small><?=__("Deixant en blanc no hi haurà límit","TXOAuthorsWidget")?></small></em>
			</p>		
	
<?php
	}
}



function TXO_Authors_Widget_style() {
	$plugin_url = plugins_url ( plugin_basename ( dirname ( __FILE__ ) ) );
	
	wp_register_style('TXO_Authors_Widget_style', $plugin_url.'/style.css');
	wp_enqueue_style( 'TXO_Authors_Widget_style');
}

add_action('wp_print_styles', 'TXO_Authors_Widget_style');

add_action('widgets_init', create_function('', 'return register_widget("TXO_Authors_Widget");'));


