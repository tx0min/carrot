(function($){

	$(document).ready(function() {
	
		
		$('li.txo-archive-year a.icon').click(function() {
			$(this).toggleClass('more');
				
			$(this).parent().children('ul').slideToggle('fast');
			return false;
		});	
		$('.widget_txoarchivewidget li:first-child').find('a').click();
	});

})(jQuery);