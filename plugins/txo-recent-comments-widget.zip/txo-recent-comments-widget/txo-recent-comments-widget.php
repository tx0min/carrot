<?php 
/*
Plugin Name: TXO Recent Comments 
Description: Llista les entrades amb comentaris recents
Version: 1.0
Author: Mensula
*/





class TXO_Recent_Comments_Widget extends WP_Widget {

	function TXO_Recent_Comments_Widget() {
		/* Widget settings. */
		$widget_ops = array( 
			'classname' => 'TXO_Recent_Comments_Widget', 
			'description' => 'Llista les entrades amb comentaris recents' 
		);

		/* Widget control settings. */
		//$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'example-widget' );

		/* Create the widget. */
		$this->WP_Widget( 'TXORecentCommentsWidget-widget', 'TXO Recent Comments Widget', $widget_ops);
	}
	
	function get_time_diff($time) {

      $difference = time() - strtotime($time);
      
      $weeks = round($difference / 604800);  
      $difference = $difference % 604800;
      $days = round($difference / 86400);
      $difference = $difference % 86400;
      $hours = round($difference / 3600);
      $difference = $difference % 3600;
      $minutes = round($difference / 60);
      $difference = $difference % 60;
      $seconds = $difference;
      
      if ($weeks > 0)
         return sprintf( __('Fa %s setmanes', "TXORecentCommentsWidget"),$weeks);
      else if ($days > 0)
         return sprintf( __('Fa %s dies', "TXORecentCommentsWidget"),$days);
      else if ($hours > 0)
         return sprintf( __('Fa %s hores', "TXORecentCommentsWidget"),$hours);
      else if ($minutes > 0)
         return sprintf( __('Fa %s minuts', "TXORecentCommentsWidget"),$minutes);
      else if ($seconds > 0)
         return sprintf( __('Fa %s segons', "TXORecentCommentsWidget"),$seconds);

   }
	
	function widget( $args, $instance ) {
		global $wpdb;
		extract( $args );

		/* User-selected settings. */
		$title = apply_filters('widget_title', $instance['title'] );
		
		$show_foto = isset( $instance['SHOW_AVATAR'] ) ? $instance['SHOW_AVATAR'] : false;
		$limit_number = isset( $instance['LIMIT_NUMBER'] ) ? $instance['LIMIT_NUMBER'] : "";
		$foto_type = isset( $instance['FOTO_TYPE'] ) ? $instance['FOTO_TYPE'] : "featured";
		
		
		if(is_nan((int)$limit_number)) $limit_number="";
		
		/* Before widget (defined by themes). */
		echo $before_widget;

		/* Title of widget (before and after defined by themes). */
		if ( $title )
			echo $before_title . $title . $after_title;

		
		
		 $sql = "SELECT a.*, b.post_title from $wpdb->comments a JOIN $wpdb->posts b ON a.comment_post_id = b.id WHERE comment_approved= '1' AND a.comment_type != 'pingback'
              ORDER BY comment_date DESC ";
		if($limit_number && $limit_number>0) $sql.=" LIMIT " . $limit_number;
      
		
		$comments = $wpdb->get_results($sql);
		
		 foreach ($comments as $comment) {
			
			$author_has_url = !(empty($comment->comment_author_url) || 'http://' == $comment->comment_author_url);
			$url_author = '<a href="' . $comment->comment_author_url . '" title="' . $comment->comment_author . '" rel="external nofollow" target="_blank">'.$comment->comment_author.'</a>';
			
			$url=$author_has_url ? $url_author : '<span title="' . $comment->comment_author . '">'.$comment->comment_author.'</span>';
								
           
							   
							
			
?>
<article class="article-separation-smallgap header-separation-none thumb-left foto-<?=$foto_type?>">

	<div class="article-inner">
	
		<div class="row">
				<div class="col-xs-3 ">
					<div class="article-featured ">
						<?php 
							if($foto_type=="featured"){
								theme_post_thumbnail_by_id($comment->comment_post_ID,'icon',false, false, true); 
							}else{
								if($author_has_url) echo  '<a href="' . $comment->comment_author_url . '" title="' . $comment->comment_author .'" rel="external nofollow"  target="_blank">';
								echo get_avatar($comment->comment_author_email, 96);
								if($author_has_url) echo  '</a>';
            
								//theme_author_args(array("name"=>false,"avatar"=>true,"bio"=>false,"prefix"=>false,"twitter"=>false,"email"=>false));
							}
						?>
					</div>
				</div>
						
						
				<div class="col-xs-9">
					<header class="entry-header clearfix">
						<h3 class="entry-title ">
							<a href="<?=get_permalink($comment->comment_post_ID)?>"><?=$comment->post_title?></a>
						</h3>
														
						<div class="comment-author">
							<span class="author-info"><?php echo sprintf( __('Per %s ', "TXORecentCommentsWidget"),$url); ?></span> | <?=$this->get_time_diff($comment->comment_date_gmt)?>
						</div>
					</header><!-- .entry-header -->
				</div>
						
		</div>
	</div>
</article>
<?php			
		 }
		
		

		/* After widget (defined by themes). */
		echo $after_widget;
	}
	
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
		/* Strip tags (if needed) and update the widget settings. */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['SHOW_AVATAR'] = $new_instance['SHOW_AVATAR'];
		$instance['FOTO_TYPE'] = $new_instance['FOTO_TYPE'];
		$instance['LIMIT_NUMBER'] = $new_instance['LIMIT_NUMBER'];

		
		
		return $instance;
	}
	
	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 
			'title' => __('Comentaris',"TXORecentCommentsWidget"), 
			'SHOW_AVATAR' => true,
			'FOTO_TYPE' => "featured",
			'LIMIT_NUMBER' => ""
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		//print_r($instance);
?>
			<p>
				<label for="<?=$this->get_field_id( 'title' ) ?>"><?=__('Títol:',"TXORecentCommentsWidget")?></label>
				<input name="<?=$this->get_field_name( 'title' )?>" id="<?=$this->get_field_id( 'title' ) ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'SHOW_AVATAR' )?>"><?=__('Mostrar imatge:',"TXORecentCommentsWidget")?></label>
				<input type="checkbox" <?php checked( $instance['SHOW_AVATAR'], 'on' ); ?>  name="<?=$this->get_field_name( 'SHOW_AVATAR' )?>" id="<?=$this->get_field_id( 'SHOW_AVATAR' ) ?>"  />
			</p>
			<p>
			
				<label for="<?php echo $this->get_field_id( 'FOTO_TYPE' ); ?>"><?=__("Imatge a mostrar:","TXORecentCommentsWidget")?></label> 
				<select id="<?php echo $this->get_field_id( 'FOTO_TYPE' ); ?>" name="<?php echo $this->get_field_name( 'FOTO_TYPE' ); ?>" class="widefat" >
					<option value="featured" <?php if ( $instance['FOTO_TYPE']=="featured" || !$instance['FOTO_TYPE'] ) echo ' selected="selected" ' ;?>><?=__('Imatge destacada',"TXORecentCommentsWidget")?></option>
					<option value="avatar"  <?php if ( $instance['FOTO_TYPE']=="avatar"  ) echo ' selected="selected" ' ;?>><?=__('Avatar de l\'autor',"TXORecentCommentsWidget")?></option>
				</select>
			</p>
			<p>
				<label for="<?=$this->get_field_id( 'LIMIT_NUMBER' )?>"><?=__("Número d'articles mostrats:","TXORecentCommentsWidget")?></label>
				<input type="text" name="<?=$this->get_field_name( 'LIMIT_NUMBER' )?>" id="<?=$this->get_field_id( 'LIMIT_NUMBER' ) ?>"  value="<?=$instance['LIMIT_NUMBER']?>"/>
				<br/>
				<em><small><?=__("Deixant en blanc no hi haurà límit","TXORecentCommentsWidget")?></small></em>
			</p>		
	
<?php
	}
}



function TXO_Recent_Comments_Widget_style() {
	$plugin_url = plugins_url ( plugin_basename ( dirname ( __FILE__ ) ) );
	
	wp_register_style('TXO_Recent_Comments_Widget_style', $plugin_url.'/style.css');
	wp_enqueue_style( 'TXO_Recent_Comments_Widget_style');
}

add_action('wp_print_styles', 'TXO_Recent_Comments_Widget_style');

add_action('widgets_init', create_function('', 'return register_widget("TXO_Recent_Comments_Widget");'));







