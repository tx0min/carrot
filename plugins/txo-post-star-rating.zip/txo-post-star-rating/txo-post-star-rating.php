<?php
/*
Plugin Name: TXO Post Star Rating 
Description: Posts Star rating system
Version: 1.0
Author: Mensula
*/

define ("TXO_PSR_TEXTDOMAIN","txo-post-star-rating");

include dirname( __FILE__ ) ."/txo-psr-widget-best-of-month.php";
include dirname( __FILE__ ) ."/txo-psr-widget-best-of-moment.php";

/*
* Create tables in the database.
*/
if ( ! function_exists ( 'txo_psr_create_table' ) ) {
	function txo_psr_create_table() {
		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		$psr_table_post = $wpdb->prefix . 'txo_psr_post';
		$psr_table_user = $wpdb->prefix . 'txo_psr_user';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$psr_table_post}'" ) !== $psr_table_post ) {
			$sql = "CREATE TABLE {$psr_table_post} (
				ID bigint(20) unsigned NOT NULL default '0',
				votes int(10) unsigned NOT NULL default '0',
				points int(10) unsigned NOT NULL default '0',
				PRIMARY KEY (ID));";
			dbDelta( $sql );
		}
		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$psr_table_user}'" ) !== $psr_table_user ) {
			$sql = "CREATE TABLE {$psr_table_user} (
				user varchar(32) NOT NULL default '',
				post bigint(20) unsigned NOT NULL default '0',
				points int(10) unsigned NOT NULL default '0',
				ip char(15) NOT NULL,
				vote_date datetime NOT NULL,
				PRIMARY KEY (`user`,post),
				KEY vote_date (vote_date));";
			dbDelta( $sql );
		}
	}
}

/*
* Add localization to the plugin and create user for voting.
*/
if ( ! function_exists( 'txo_psr_init' ) ) {
	function txo_psr_init() {
		load_plugin_textdomain( TXO_PSR_TEXTDOMAIN, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		if ( ! isset( $_COOKIE['txo_psr'] ) ) {
			$psr_user = md5( microtime() . rand( 1000, 90000000 ) );
			setcookie( 'txo_psr', $psr_user, time() + 60 * 60 * 24 * 365, '/' );
		}
	}
}

/*
* Add script and styles to the front-end.
*/
if ( ! function_exists( 'txo_psr_frontend_head' ) ) {
	function txo_psr_frontend_head() {
		wp_enqueue_style( 'txo_psr_style', plugins_url( 'css/style.css', __FILE__ ) );
		wp_enqueue_script( 'txo_psr_script', plugins_url( 'js/script.js', __FILE__ ), array( 'jquery' ) );
		wp_localize_script( 'txo_psr_script', 'psr_ajax',
			array(
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( plugin_basename( __FILE__ ), 'psr_ajax_nonce' )
			)
		);
	}
}

/*
* Get the html that shows the stars for voting. If the user has already vote then it shows stars with puntuation. No voting is allowed.
*/
if ( ! function_exists( 'txo_psr_show_voting_stars' ) ) {
	function txo_psr_show_voting_stars( $psr_post_id = false, $psr_points = false ) {
		global $wpdb, $post;
		$psr_rated = false;
		$psr_user = isset( $_COOKIE['txo_psr'] ) ? esc_sql( $_COOKIE['txo_psr'] ) : false;
		$psr_table_user = $wpdb->prefix . 'txo_psr_user';
		$psr_table_post = $wpdb->prefix . 'txo_psr_post';
		if ( ! $psr_post_id ) {
			$psr_post_id = $post->ID;
		}
		if ( $psr_user ) {
			$psr_rated = (bool) $wpdb->get_var(
				"SELECT COUNT(*)
				FROM {$psr_table_user}
				WHERE user='{$psr_user}'
				AND post={$psr_post_id}"
			);
		}
		if ( $psr_user && $psr_points > 0 && ! $psr_rated ) {
			$psr_ip = $_SERVER['REMOTE_ADDR'];
			$psr_vote_date = date( 'Y-m-d H:i:s' );
			$wpdb->query(
				"INSERT INTO {$psr_table_user} (user, post, points, ip, vote_date)
				VALUES ('{$psr_user}', {$psr_post_id}, {$psr_points}, '{$psr_ip}', '{$psr_vote_date}')"
			);
			if ( $wpdb->get_var( "SELECT COUNT(*) FROM {$psr_table_post} WHERE ID={$psr_post_id}" ) ) {
				$wpdb->query(
					"UPDATE {$psr_table_post}
					SET votes=votes+1, points=points+{$psr_points}
					WHERE ID={$psr_post_id};"
				);
			} else {
				$wpdb->query(
					"INSERT INTO {$psr_table_post} (ID, votes, points)
					VALUES ({$psr_post_id}, 1, {$psr_points});"
				);
			}
			$psr_rated = true;
		}
		$psr_data = $wpdb->get_row( "SELECT votes, points FROM {$psr_table_post} WHERE ID={$psr_post_id}" );
		$psr_data_votes = isset( $psr_data->votes ) ? (int) $psr_data->votes : 0;
		$psr_data_points = isset( $psr_data->points ) ? (int) $psr_data->points : 0;



		if ( $psr_rated || ! $psr_user ) {
			$psr_html = txo_psr_draw_stars( $psr_data_votes, $psr_data_points );
		} else {
			$psr_html = txo_psr_draw_voting_stars( $psr_data_votes, $psr_data_points, $psr_post_id );
		}
		echo $psr_html;
	}
}

/*
* Draw the stars.
*/
if ( ! function_exists( 'txo_psr_draw_stars' ) ) {
	function txo_psr_draw_stars( $psr_votes, $psr_points, $show_count=true) {
		if ( $psr_votes > 0 ) {
			$psr_rate = $psr_points / $psr_votes;
		} else {
			$psr_rate = 0;
		}
		$psr_html = '<div class="PSR_container"><div class="PSR_stars">';
		for ( $i = 1; $i <= 5; ++$i ) {
			if ( $i <= $psr_rate ) {
				$psr_class = 'PSR_full_star';
				$psr_char = '*';
			} elseif ( $i <= ( $psr_rate + .5 ) ) {
				$psr_class = 'PSR_half_star';
				$psr_char = '&frac12;';
			} else {
				$psr_class = 'PSR_no_star';
				$psr_char = '&nbsp;';
			}
			$psr_html .= sprintf( '<span class="%s">%s</span>', $psr_class, $psr_char );
		}
		if($show_count)
			$psr_html .= sprintf( '<span class="PSR_votes">%d</span><span class="PSR_tvotes">%s</span>', $psr_votes, _n( 'vote', 'votes', $psr_votes, TXO_PSR_TEXTDOMAIN) );
		
		$psr_html .= '</div></div>';
		return $psr_html;
	}
}

/*
* Draw the voting stars.
*/
if ( ! function_exists( 'txo_psr_draw_voting_stars' ) ) {
	function txo_psr_draw_voting_stars( $psr_votes, $psr_points, $psr_post_id ) {
		if ( $psr_votes > 0 ) {
			$psr_rate = $psr_points / $psr_votes;
		} else {
			$psr_rate = 0;
		}
		$psr_html = sprintf( '<div class="PSR_container"><form id="PSR_form_%1$d" action="#PSR_form_%1$d" method="post" class="PSR_stars">', $psr_post_id );
		for ( $i = 1; $i <= 5; ++$i ) {
			if ( $i <= $psr_rate ) {
				$psr_class = 'PSR_full_voting_star';
				$psr_char = '*';
			} elseif ( $i <= ( $psr_rate + .5 ) ) {
				$psr_class = 'PSR_half_voting_star';
				$psr_char = '&frac12;';
			} else {
				$psr_class = 'PSR_no_voting_star';
				$psr_char = '&nbsp;';
			}
			$psr_html .= sprintf(
				'<input type="radio" id="psr_star_%1$d_%2$d" class="psr_star" name="psr_stars" value="%2$d" /><label class="%3$s" for="psr_star_%1$d_%2$d">%2$d</label> ',
				$psr_post_id,
				$i,
				$psr_class
			);
		}
		if ( $psr_votes > 0 ) {
			$psr_html .= sprintf( '<span class="PSR_votes">%d</span><span class="PSR_tvotes">%s</span>', $psr_votes, _n( 'vote', 'votes', $psr_votes, TXO_PSR_TEXTDOMAIN ) );
		} else {
			$psr_html .= sprintf( '<span class="PSR_tvote">%s</span>', __( 'Vote!', TXO_PSR_TEXTDOMAIN ) );
		}
		$psr_html .= sprintf( '<input type="hidden" name="p" value="%d" />', $psr_post_id );
		$psr_html .= sprintf( '<input type="submit" name="vote" value="%s" />', __( 'Vote', TXO_PSR_TEXTDOMAIN ) );
		$psr_html .= '</form></div>';
		return $psr_html;
	}
}

/*
* Save vote post to database.
*/
if ( ! function_exists( 'txo_psr_save_vote' ) ) {
	function txo_psr_save_vote() {
		check_ajax_referer( plugin_basename( __FILE__ ), 'psr_ajax_nonce' );
		$psr_post_id = isset( $_POST['psr_post_id'] ) ? $_POST['psr_post_id'] : false;
		$psr_points = ( isset( $_POST['psr_points'] ) && $_POST['psr_points'] > 0 && $_POST['psr_points'] <= 5 ) ? (int) $_POST['psr_points'] : false;
		if ( $psr_post_id && $psr_points ) {
			txo_psr_show_voting_stars( $psr_post_id, $psr_points );
		}
		exit;
	}
}

/*
* Draw the best post of the month.
*/
if ( ! function_exists( 'txo_psr_bests_of_month' ) ) {
	function txo_psr_bests_of_month( $psr_month = null, $args=null ) {
		global $wpdb;
		
		
		$psr_month = is_null( $psr_month ) ? date( 'm' ) : (int) $psr_month;
		if(!$args) $args=array();
		$psr_limit = isset($args["limit_number"])?$args["limit_number"]:10;
		$show_foto = (isset($args["show_foto"]) && $args["show_foto"]);
		$show_count = (isset($args["show_count"]) && $args["show_count"]);
		
		$psr_table_user = $wpdb->prefix . 'txo_psr_user';
		
		$q="SELECT post, COUNT(*) AS votes, SUM(points) AS points, AVG(points)
			FROM {$psr_table_user}
			WHERE MONTH(vote_date)={$psr_month} AND YEAR(vote_date)=YEAR(NOW())
			GROUP BY 1
			ORDER BY 4 DESC, 2 DESC";
		if($psr_limit>0) $q.=" LIMIT {$psr_limit}";
		
			
		$psr_data = $wpdb->get_results($q);
		if ( is_array( $psr_data ) ) {
			$psr_html = '<div class="PSR_month_scores">';
			foreach ( $psr_data AS $psr_row ) {
				
				
				$psr_permalink = get_permalink( $psr_row->post );
				$psr_title = get_the_title( $psr_row->post );
				$colsize=9;
				if(!$show_foto) $colsize=12;
				
				$psr_html.='
					<article class="article-separation-smallgap header-separation-none thumb-left ">
						<div class="article-inner">
							<div class="row">
									<div class="col-xs-'.(12-$colsize).' ">
										';
										if($show_foto){
											$psr_html.='<div class="article-featured ">
												'.
												get_post_thumbnail_by_id($psr_row->post,'icon',false, false, true) 					
											.'</div>';
										}
				$psr_html.='		</div>
											
											
									<div class="col-xs-'.($colsize).'">
										<header class="entry-header clearfix">
											<h3 class="entry-title ">
												<a href="'.$psr_permalink.'">'.$psr_title.'</a>
											</h3> '
											. txo_psr_draw_stars( $psr_row->votes, $psr_row->points,$show_count ).
											
										'</header><!-- .entry-header -->
									</div>
											
							</div>
						</div>
					</article>
';			
				
				
				
				
			}
			
			$psr_html .= '</div>';
			return $psr_html;
		}
	}
}

/*
* Shortcode for display the best post of the month.
*/
if ( ! function_exists( 'txo_psr_get_bests_of_month' ) ) {
	function txo_psr_get_bests_of_month( $atts ) {
		$psr_month = isset( $atts['month'] ) ? $atts['month'] : null;
		$psr_limit = isset( $atts['limit'] ) ? $atts['limit'] : 10;
		return txo_psr_bests_of_month( $psr_month, $psr_limit );
	}
}

/*
* Draw the best post of the moment. The moment is the time between now and 30 days before.
*/
if ( ! function_exists( 'txo_psr_bests_of_moment' ) ) {
	function txo_psr_bests_of_moment( $args=null ) {
		global $wpdb;
		if(!$args) $args=array();
		
		$psr_limit = isset($args["limit_number"])?$args["limit_number"]:10;
		$show_foto = (isset($args["show_foto"]) && $args["show_foto"]);
		$show_count = (isset($args["show_count"]) && $args["show_count"]);
		
		$psr_table_user = $wpdb->prefix . 'txo_psr_user';
		
		$psr_avg = (int) $wpdb->get_var(
			"SELECT COUNT(*) / COUNT( DISTINCT post ) AS votes
			FROM {$psr_table_user}
			WHERE vote_date BETWEEN DATE_SUB(DATE_SUB(NOW(), INTERVAL 1 DAY), INTERVAL 1 MONTH)
			AND DATE_SUB(NOW(), INTERVAL 1 DAY)"
		);
		$q="SELECT post, COUNT(*) AS votes, SUM(points) AS points, AVG(points)
			FROM {$psr_table_user}
			WHERE vote_date BETWEEN DATE_SUB(DATE_SUB(NOW(), INTERVAL 1 DAY), INTERVAL 1 MONTH)
			AND DATE_SUB(NOW(), INTERVAL 1 DAY)
			GROUP BY 1
			HAVING votes > {$psr_avg}
			ORDER BY 4 DESC, 2 DESC";
		if($psr_limit>0) $q.=" LIMIT {$psr_limit}";
		
		$psr_data = $wpdb->get_results( $q);
		
		
		
		$psr_old_score = array();
		if ( is_array( $psr_data ) ) {
			$i = 1;
			foreach ( $psr_data AS $psr_row ) {
				$psr_old_score[ $psr_row->post ] = $i++;
			}
		}
		$psr_avg = (int) $wpdb->get_var(
			"SELECT COUNT(*) / COUNT( DISTINCT post ) AS votes
			FROM {$psr_table_user}
			WHERE vote_date BETWEEN DATE_SUB(NOW(), INTERVAL 1 MONTH)
			AND NOW()"
		);
		//_dump($psr_avg);
		$q2="SELECT post, COUNT(*) AS votes, SUM(points) AS points, AVG(points)
			FROM {$psr_table_user}
			WHERE vote_date BETWEEN DATE_SUB(NOW(), INTERVAL 1 MONTH)
			AND NOW()
			GROUP BY 1
			HAVING votes > {$psr_avg}
			ORDER BY 4 DESC, 2 DESC";
		if($psr_limit>0) $q2.=" LIMIT {$psr_limit}";
			
		
		$psr_score = $wpdb->get_results($q2);
		
		if ( is_array( $psr_score ) ) {
			$psr_html = '<div class="PSR_moment_scores">';
			$psr_position = 1;
			$psr_trends = array( __( 'Down', TXO_PSR_TEXTDOMAIN ), __( 'Up', TXO_PSR_TEXTDOMAIN ), __( 'Unchanged', TXO_PSR_TEXTDOMAIN ) );
			foreach ( $psr_score AS $psr_row ) {
			
			
				$psr_permalink = get_permalink( $psr_row->post );
				$psr_title = get_the_title( $psr_row->post );
				$colsize=9;
				if(!$show_foto) $colsize=12;
				
				$psr_html.='
					<article class="article-separation-smallgap header-separation-none thumb-left ">
						<div class="article-inner">
							<div class="row">';
							if($show_foto){
								$psr_html.='	<div class="col-xs-'.(12-$colsize).' ">
													<div class="article-featured ">
													'.
													get_post_thumbnail_by_id($psr_row->post,'icon',false, false, true) 					
												.'</div>
												</div>';
							}			
											
							$psr_html.='		<div class="col-xs-'.($colsize).'">
										<header class="entry-header clearfix">
											<h3 class="entry-title ">
												<a href="'.$psr_permalink.'">'.$psr_title.'</a>
											</h3> ';
										
										
				if ( is_array( $psr_old_score ) ) {
					$psr_trend = sprintf( '<span class="trend trend_up" title="%s"><i class="ti ti-angle-double-up"></i></span>',  $psr_trends[1] );
					if ( isset( $psr_old_score[ $psr_row->post ] ) ) {
						if ( $psr_position > $psr_old_score[ $psr_row->post ] ) {
							$psr_trend = sprintf( '<span class="trend trend_dw " title="%s"><i class="ti ti-angle-double-down"></i></span>',  $psr_trends[0] );
							//$psr_trend = sprintf( '<span class="trend trend_dw" title="%s"><img src="%s"></span>', $psr_trends[0], plugins_url( 'images/dw_arrow.png', __FILE__ ) );
						} elseif ($psr_position == $psr_old_score[ $psr_row->post ] ) {
							$psr_trend = sprintf( '<span class="trend trend_eq " title="%s"><i class="ti ti-arrows-horizontal"></i></span>',  $psr_trends[2] );
							//$psr_trend = sprintf( '<span class="trend trend_eq" title="%s"><img src="%s"></span>', $psr_trends[2], plugins_url( 'images/eq_arrow.png', __FILE__ ) );
						}
					}
					$psr_html .= $psr_trend;
				}	
				
											
				$psr_html.= txo_psr_draw_stars( $psr_row->votes, $psr_row->points,$show_count );
											
				$psr_html.= 			'</header><!-- .entry-header -->
									</div>
											
							</div>
						</div>
					</article>
			';			
		
			
				
				
				
				
				$psr_position++;
			}
			$psr_html .= '</div>';
			return $psr_html;
		}
	}
}

/*
* Shortcode for display the best post of the moment.
*/
if ( ! function_exists( 'txo_psr_get_bests_of_moment' ) ) {
	function txo_psr_get_bests_of_moment( $atts ) {
		$args=array(
			"show_foto"=> (isset( $atts['show_image'] ) && $atts['show_image']),
			"limit_number"=>isset( $atts['limit'] ) ? $atts['limit'] : 10,
			"show_count"=>(isset( $atts['show_count'] ) && $atts['show_count'])
		);
		return txo_psr_bests_of_moment( $args );
	}
}

/* Create DB tables */
register_activation_hook( __FILE__, 'txo_psr_create_table' );
/* Initialization */
add_action( 'init', 'txo_psr_init' );
/* Adding scripts and styles to the frontend */
add_action( 'wp_enqueue_scripts', 'txo_psr_frontend_head' );
/* Adding a plugin support shortcode */
add_shortcode( 'txo_psr_bests_of_month', 'txo_psr_get_bests_of_month' );
add_shortcode( 'txo_psr_bests_of_moment', 'txo_psr_get_bests_of_moment' );
/* Adding ajax support for voting */
add_action( 'wp_ajax_psr_save_vote', 'txo_psr_save_vote' );
add_action( 'wp_ajax_nopriv_psr_save_vote', 'txo_psr_save_vote' );




if ( ! function_exists( 'theme_stars_rating_active' ) ) :
	function theme_stars_rating_active() {
		 if( !function_exists( 'txo_psr_show_voting_stars' ) ) return false;
		 if(is_single() && !has_field("star_rating") ) return true;
		 if(is_single()	&& !gf('star_rating')) return false;
		 return true;

	}
endif;



if ( ! function_exists( 'theme_stars_voting' ) ) :
	function theme_stars_voting() {
		if(theme_stars_rating_active()){
			txo_psr_show_voting_stars();
		}
	}
endif;

if ( ! function_exists( 'theme_stars_best_of_month' ) ) :
	function theme_stars_best_of_month() {
		if(theme_stars_rating_active()) echo do_shortcode('[txo_psr_bests_of_month]');
		//echo do_shortcode('[psr_bests_of_moment]');
	}
endif;

if ( ! function_exists( 'theme_stars_best_of_moment' ) ) :
	function theme_stars_best_of_moment() {
		if(theme_stars_rating_active()) echo do_shortcode('[txo_psr_bests_of_moment]');
		//echo do_shortcode('[psr_bests_of_moment]');
	}
endif;
